﻿/*
 * SPI.h
 *
 * Created: 20/10/2020 09:34:36 ص
 *  Author: hp
 */ 


#ifndef SPI_H_
#define SPI_H_
#include "DIO.h"
#include "SPI_REG.h"
typedef enum{
	SRP0=0,
	SPR1,
	CPHA,
	CPOL,
	MSTR,
	DORD,
	SPE,
	SPIE
	}SPCR_Bits;
	
typedef enum{
	WCOL=6,
	SPIF
	}SPSR_Bits;
#define Slave_EN()  PORTB_REG&=~(1<<4)
#define Slave_DIS()  PORTB_REG|=(1<<4)
void SPI_Write(char data);
void SPI_Init(unsigned char status);
char SPI_Read();
char SPI_Receive();
//unsigned char SPI_TxRx(unsigned char Data);
#endif /* SPI_H_ */
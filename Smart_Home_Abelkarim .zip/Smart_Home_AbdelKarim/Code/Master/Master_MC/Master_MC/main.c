/*
 * Master_MC.c
 *
 * Created: 20/10/2020 12:03:38 م
 * Author : hp
 */ 
#include "LCD.h"
#include "SPI.h"
#include "UART.h"
#include <stdlib.h>
int main(void)
{ 
	LCD_Init();
	UART_Init();
	SPI_Init('M');
	Slave_EN();
	LCD_POS(First_Line,0);
	LCD_String("Abd_EL_Karim");
	LCD_POS(Second_Line,4);
	LCD_String("SMART HOME");
	while (1)
	{
		switch(UART_Rx()){
		case '1':
			SPI_Write('1');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("LED IS ON");
		break;
		case '2':
			SPI_Write('2');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("LED IS OFF");
		break;
		case '3':
			SPI_Write('3');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("MOTOR IS ON");
		break;
		case '4':
			SPI_Write('4');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("MOTOR IS OFF");
		break;
		case '5':
			SPI_Write('5');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("Reading temperature ");
		break;
		case '+':
			SPI_Write('+');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("Motor Speed + ");
		break;
		case '-':
			SPI_Write('-');
			LCD_POS(First_Line,0);
			LCD_CMD(0x01);
			LCD_String("Motor Speed - ");
		break;
	}	
}
}


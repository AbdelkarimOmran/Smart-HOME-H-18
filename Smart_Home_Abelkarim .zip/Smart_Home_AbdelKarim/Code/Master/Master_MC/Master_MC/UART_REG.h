﻿/*
 * UART_REG.h
 *
 * Created: 19/10/2020 11:57:50 ص
 *  Author: Abelkarim
 */ 


#ifndef UART_REG_H_
#define UART_REG_H_

#define UBRRL_REG 	(*((volatile Uint8*)(0x29)))
											  
#define UBRRH_REG	(*((volatile Uint8*)(0x40)))
											  
#define UCSRA_REG 	(*((volatile Uint8*)(0x2B)))
											  
#define UCSRB_REG 	(*((volatile Uint8*)(0x2A)))
											  
#define UCSRC_REG 	(*((volatile Uint8*)(0x40)))
											  
#define UDR_REG 	(*((volatile Uint8*)(0x2C)))

#endif /* UART_REG_H_ */
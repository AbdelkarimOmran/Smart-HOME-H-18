﻿/*
 * UART.c
 *
 * Created: 19/10/2020 11:58:19 ص
 *  Author: Abdelkarim
 */ 
#include "UART.h"
void UART_Init()
{
	UCSRB_REG|=(1<<RXEN)|(1<<TXEN);                  //ENABLE Tx & Rx
	UCSRC_REG|=(1<<URSEL)|(1<<UCSZ0)|(1<<UCSZ1);     //8-bit, 0 PARITY ,1 stop bit
	UBRRL_REG|=MYUBRR ;                             //low 8 bit ;
	UBRRH_REG|=(MYUBRR>>8);                         //High 4 Bit
}

void UART_Tx( char Data){
	while(!(UCSRA_REG & (1<<UDRE)));                //Wait FoR the UDR is empty;
	UDR_REG=Data;
}

Uint8 UART_Rx(){
	while(!(UCSRA_REG & (1<<RXC)));
	return UDR_REG;
}

void UART_Tx_str(char * str){
	Uint8 i=0;
	while (str[i]!='\0')
	{
		UART_Tx(str[i]);
		i++;
	}
}
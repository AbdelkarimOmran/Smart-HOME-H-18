﻿/*
 * DIO.c
 *
 * Created: 18/09/2020 03:28:44 ص
 *  Author: Abd_El_Karim
 */ 
#include "DIO.h"
void DIO_Init(DIO_ChannelTypes ChannelId, DIO_Dir Dir){
	 DIO_PortTypes Portx=ChannelId/8;
	 DIO_ChannelTypes Bitnumber=ChannelId%8;
	switch(Portx){
		case DIO_PORTA:
		if (Dir== Output)
		   SetBit(DDRA_REG,Bitnumber);
		else
		   ClearBit(DDRA_REG,Bitnumber);
		break;
		case DIO_PORTB:
		if (Dir == Output)
		   SetBit(DDRB_REG,Bitnumber);
		else
		   ClearBit(DDRB_REG,Bitnumber);
		break;
		case DIO_PORTC:
		if (Dir== Output)
		   SetBit(DDRC_REG,Bitnumber);
		else
		   ClearBit(DDRC_REG,Bitnumber);
		break;
		case DIO_PORTD:
		if (Dir == Output)
		   SetBit(DDRD_REG,Bitnumber);
		else
		   ClearBit(DDRD_REG,Bitnumber);
		break;	   
	} 	
}

void DIO_Write(DIO_ChannelTypes ChannelId,STD_levelTypes Level){
        DIO_PortTypes Portx=ChannelId/8;
		DIO_ChannelTypes Bitnumber=ChannelId%8;
		switch(Portx){
			case DIO_PORTA:
				if (Level==STD_High)
				{
					SetBit(PORTA_REG,Bitnumber);
				}
				else if (Level==STD_Low){
					ClearBit(PORTA_REG,Bitnumber);
				}
			break;
			case DIO_PORTB:
				if (Level==STD_High)
				{
					SetBit(PORTB_REG,Bitnumber);
				}
				else if (Level==STD_Low){
					ClearBit(PORTB_REG,Bitnumber);
				}
			break;
			case DIO_PORTC:
				if (Level==STD_High)
				{
					SetBit(PORTC_REG,Bitnumber);
				}
				else if (Level==STD_Low){
					ClearBit(PORTC_REG,Bitnumber);
				}
			break;
			case DIO_PORTD:
				if (Level==STD_High)
				{
					SetBit(PORTD_REG,Bitnumber);
				}
				else if (Level==STD_Low){
					ClearBit(PORTD_REG,Bitnumber);
				}
			break;
		}
		}
STD_levelTypes DIO_Read(DIO_ChannelTypes ChannelId){
	STD_levelTypes Level=0;
	DIO_PortTypes Portx = ChannelId/8;
	DIO_ChannelTypes Bitnumber = ChannelId% 8;
	switch(Portx){
		case DIO_PORTA:
		Level = GetBit(PINA_REG, Bitnumber);
		break;
		case DIO_PORTB:
		Level = GetBit(PINB_REG, Bitnumber);
		break;
		case DIO_PORTC:
		Level = GetBit(PINC_REG, Bitnumber);
		break;
		case DIO_PORTD:
		Level = GetBit(PIND_REG, Bitnumber);
		break;
	}
	return Level;
}
void DIO_Write_Port(DIO_PortTypes Portx,Uint8 Data){
	switch(Portx){
		case DIO_PORTA:
		PORTA_REG = Data;
		break;
		case DIO_PORTB:
		PORTB_REG = Data;
		break;
		case DIO_PORTC:
		PORTC_REG = Data;
		break;
		case DIO_PORTD:
		PORTD_REG = Data;
		break;
	}
}
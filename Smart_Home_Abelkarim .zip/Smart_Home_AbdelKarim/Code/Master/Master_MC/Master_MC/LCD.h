﻿/*
 * LCD.h
 *
 * Created: 01/10/2020
 *  Author: Abd_El_Karim
 */

#include "DIO.h"
#ifndef LCD_H_
#define LCD_H_
#define LCD_RS  DIO_ChannelB1
#define LCD_RW  DIO_ChannelB2
#define LCD_E   DIO_ChannelB3

#define LCD_Data_Port	DIO_PORTA
#define LCD_CMD_Port	DIO_PORTB

#define LCD_Data_REG    PORTA_REG
#define LCD_CMD_REG     PORTB_REG
#define  First_Line		 1
#define  Second_Line     2
void LCD_String(char * string);
void LCD_Char(Uint8 Data);
void LCD_CMD(Uint8 CMD);
void LCD_Init();
void LCD_Custom_Char(Uint8 Loc,Uint8* Msg);
void LCD_POS(Uint8 Line , Uint8 Pos);
#endif /* LCD_H_ */
﻿/*
 * DIO.h
 *
 * Created: 18/09/2020 03:25:24 ص
 *  Author: Abd_El_Karim
 */ 


#ifndef DIO_H_
#define DIO_H_
#define F_CPU 16000000UL
#include <util/delay.h>
#include "BitMath.h"
#include "STD_Types.h"
#include "DIO_Types.h"
#include "DIO_REG.h"
void DIO_Write(DIO_ChannelTypes ChannelId,STD_levelTypes Level);
void DIO_Write_Port(DIO_PortTypes Portx,Uint8 Data);
void DIO_Init(DIO_ChannelTypes ChannelId, DIO_Dir dir);
STD_levelTypes DIO_Read(DIO_ChannelTypes ChannelId);
#endif /* DIO_H_ */
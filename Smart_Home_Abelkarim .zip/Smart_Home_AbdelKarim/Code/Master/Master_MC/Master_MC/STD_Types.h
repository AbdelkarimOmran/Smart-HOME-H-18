﻿/*
 * STD_Types.h
 *
 * Created: 18/09/2020 03:06:28 ص
 *  Author: Abd_El_Karim 
 */ 


#ifndef STD_TYPES_H_
#define STD_TYPES_H_
typedef unsigned char Uint8 ;
typedef enum{
	STD_Low=0,
	STD_High
	}STD_levelTypes;




#endif /* STD_TYPES_H_ */
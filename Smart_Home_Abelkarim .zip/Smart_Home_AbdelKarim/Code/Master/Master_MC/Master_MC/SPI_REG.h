﻿/*
 * SPI_REG.h
 *
 * Created: 20/10/2020 12:12:41 م
 *  Author: hp
 */ 


#ifndef SPI_REG_H_
#define SPI_REG_H_
#define SPCR  (*( (volatile Uint8 *)0x2D))
#define SPSR  (*( (volatile Uint8 *)0x2E))
#define SPDR  (*( (volatile Uint8 *)0x2F))
#endif /* SPI_REG_H_ */
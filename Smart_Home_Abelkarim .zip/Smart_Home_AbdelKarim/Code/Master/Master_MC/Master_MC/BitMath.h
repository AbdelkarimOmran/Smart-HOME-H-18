﻿/*
 * BitMath.h
 *
 * Created: 18/09/2020 03:01:05 ص
 *  Author: Abd_El_Karim
 */ 


#ifndef BITMATH_H_
#define BITMATH_H_

#define  SetBit(Reg,Bit)	 (Reg|=(1<<Bit))
#define  ClearBit(Reg,Bit)	 (Reg&=~(1<<Bit))
#define  ToggleBit(Reg,Bit)	 (Reg^=(1<<Bit))
#define  GetBit(Reg,Bit)	 ((Reg<<Bit)&1)

#endif /* BITMATH_H_ */
﻿/*
 * LCD.c
 *
 * Created: 01/10/2020 
 *  Author: Abd_El_Karim
 */ 
#include "LCD.h"
void LCD_Init(void){
	DIO_Init(DIO_ChannelB1,Output);//LCD_RS
	DIO_Init(DIO_ChannelB2,Output);//LCD_RW
	DIO_Init(DIO_ChannelB3,Output);//LCD_E
	DIO_Init(DIO_ChannelA4,Output);//LCD_D4
	DIO_Init(DIO_ChannelA5,Output);//LCD_D5
	DIO_Init(DIO_ChannelA6,Output);//LCD_D6
	DIO_Init(DIO_ChannelA7,Output);//LCD_D7
	DIO_Write(LCD_RW,STD_Low);//Writing to LCD 
		_delay_ms(25);
	LCD_CMD(0x33);//initialize LCD step sending 3   3
		_delay_us(200);
	LCD_CMD(0x32);//initialize LCD step sending 3   2
	LCD_CMD(0x28);//set_function"4-Bit-Mode" "2-lines"" 5*8 pixle"
	LCD_CMD(0x06);//Entry_mood
	LCD_CMD(0x0C);//Display on
	LCD_CMD(0x01); //Clear LCD
		_delay_ms(2);
}
void LCD_CMD(Uint8 CMD){
	DIO_Write_Port(LCD_Data_Port,(LCD_Data_REG & 0x0F)|(CMD & 0xF0));
	//CMD &0xF0--> Get the bits '4,5,6,7' and Clear the '0,1,2,3'bits 
	//LCD_Data_REG & 0x0F--> Clear the bits '4,5,6,7' to receive the CMD on it without change the value of the other bits on the port
	
	DIO_Write(LCD_RS,STD_Low);// RS=0--> command mode
	DIO_Write(LCD_E,STD_High);
		_delay_us(50);
	DIO_Write(LCD_E,STD_Low);
	/*Sending a pulse for the enable*/
		_delay_ms(2);
		
	DIO_Write_Port(LCD_Data_Port,(LCD_Data_REG & 0x0F)|(CMD<<4));
	//(CMD<<4) Shift the data from the '0,1,2,3'bits to Get the bits '4,5,6,7' and Clear the '0,1,2,3'bits 
	//(LCD_Data_REG & 0x0F) Clear the bits '4,5,6,7' on the port to receive the data on it.
	DIO_Write(LCD_RS,STD_Low);// RS=0-->Send Command
	DIO_Write(LCD_E,STD_High);
		_delay_us(50);
	DIO_Write(LCD_E,STD_Low);
	/*Sending a pulse for the enable*/
		_delay_ms(2);
}
void LCD_Char(Uint8 Data){
	
	DIO_Write_Port(LCD_Data_Port,(LCD_Data_REG & 0x0F)|(Data & 0xF0));
	DIO_Write(LCD_RS,STD_High);//-->Send Data
	DIO_Write(LCD_E,STD_High);
		_delay_us(50);
	DIO_Write(LCD_E,STD_Low);
	/*Sending a pulse for the enable*/
		_delay_ms(2);
	
	DIO_Write_Port(LCD_Data_Port,(LCD_Data_REG & 0x0F)|(Data<<4));
	DIO_Write(LCD_RS,STD_High);//-->Send Data
	DIO_Write(LCD_E,STD_High);
		_delay_us(50);
	DIO_Write(LCD_E,STD_Low);
	/*Sending a pulse for the enable*/
		_delay_ms(2);
}
void LCD_String(char * string){
	Uint8 count = 0;
	while(string[count] != '\0'){
		LCD_Char(string[count]);
		count++;
	}
}
void LCD_POS(Uint8 Line , Uint8 Pos){
	
	switch(Line){
	case First_Line:
		LCD_CMD((0x80 | (Pos & 0x0F)));
	break;
	case Second_Line:
		LCD_CMD((0xC0 | (Pos & 0x0F)));
	break;
	}
}
void LCD_Custom_Char(Uint8 Loc,Uint8* Msg){
	if (Loc<8)
	{
		LCD_CMD(0x40+(Loc*8));
		for(Uint8 i=0;i<=7;i++){
				LCD_Char(Msg[i]);	
			}
	}
}
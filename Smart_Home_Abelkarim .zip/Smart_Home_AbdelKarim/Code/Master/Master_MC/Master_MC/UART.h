﻿/*
 * UART.h
 *
 * Created: 19/10/2020 11:58:07 ص
 *  Author: Abdelkarim
 */ 
#ifndef UART_H_
#define UART_H_
#include "UART_REG.h"
#include "DIO.h"
#define  BaudRate	  9600
#define F_CPU          16000000UL
#define  MYUBRR		((F_CPU/(BaudRate * 16UL) )-1)

void UART_Init();
Uint8 UART_Rx();
void UART_Tx (char Data);
void UART_Tx_str(char*str);

typedef enum{
	UDRE=5,
	TXC,
	RXC
	}UCSRA_Bits;
typedef enum{
	UCSZ2=2,
	TXEN,
	RXEN,
	UDRIE,
	TXCIE,
	RXCIE
	}UCSRB_Bits;
typedef enum{
	UCPOL=0,
	UCSZ0,
	UCSZ1,
	USBS,
	UPM0,
	UPM1,
	UMSEL,
	URSEL 
	}UCSRC_Bits;
#endif /* UART_H_ */
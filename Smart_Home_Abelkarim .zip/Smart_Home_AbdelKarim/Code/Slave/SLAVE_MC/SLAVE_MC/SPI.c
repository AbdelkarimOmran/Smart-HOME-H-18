﻿/*
 * SPI.c
 *
 * Created: 20/10/2020 09:34:54 ص
 *  Author: hp
 */ 
#include "SPI.h"

void SPI_Init(unsigned char status){
		DIO_Init(DIO_ChannelB4,Output);
		DIO_Init(DIO_ChannelB5,Output);
		DIO_Init(DIO_ChannelB6,Input);
		DIO_Init(DIO_ChannelB7,Output);
		SPCR|=(1<<SPR1);
	switch(status){
		case 'M':
		DIO_Write(DIO_ChannelB4,STD_High);//SS
		DIO_Write(DIO_ChannelB5,STD_High);//MOSI
		DIO_Write(DIO_ChannelB6,STD_Low);//MISO
		DIO_Write(DIO_ChannelB7,STD_High);//SCK
		SPCR|=(1<<MSTR)|(1<<SPE);
		Slave_DIS();
		break;
		case 'S':
		DIO_Write(DIO_ChannelB4,STD_Low);//SS
		DIO_Write(DIO_ChannelB5,STD_Low);//MOSI
		DIO_Write(DIO_ChannelB6,STD_High);//MISO
		DIO_Write(DIO_ChannelB7,STD_Low);//SCK
		SPCR|=(1<<SPE);
		break;
	}
	//SPCR|=(1<<SPE);
}
/*unsigned char SPI_TxRx(unsigned char Data){
	SPDR = Data;
	while(!(SPSR & (1<<SPIF)));
	return SPDR;
}*/
void SPI_Write(char data)		/* SPI write data function */
{
	SPDR = data;			/* Write data to SPI data register */
	while(!(SPSR & (1<<SPIF)));	/* Wait till transmission complete */
	/* Flush received data */
	/* Note: SPIF flag is cleared by first reading SPSR (with SPIF set) and then accessing SPDR hence flush buffer used here to access SPDR after SPSR read */
}
char SPI_Read()				/* SPI read data function */
{
	SPDR = 0xFF;
	while(!(SPSR & (1<<SPIF)));	/* Wait till reception complete */
	return(SPDR);			/* Return received data */
}
char SPI_Receive()			/* SPI Receive data function */
{
	while(!(SPSR & (1<<SPIF)));	/* Wait till reception complete */
	return(SPDR);			/* Return received data */
}
﻿/*
 * TIMER0.h
 *
 * Created: 18/10/2020 12:18:37 ص
 *  Author: hp
 */ 
#ifndef TIMER0_H_
#define TIMER0_H_
#include "TIMER0_REG.h"
#include "DIO.h"

typedef enum{
	CS00=0,
	CS01,
	CS02,
	WGM01,
	COM00,
	COM01,
	WGM00
}TCCR_BITS;

typedef enum{
	TOIE0=0,
	OCIE0
}TIMSK_BITS;

typedef enum{
	TOV0=0,
	OCF0
}TIFR_BITS;


#endif /* TIMER0_H_ */
﻿/*
 * ADC.h
 *
 * Created: 16/10/2020 12:01:36 ص
 *  Author: hp
 */ 
#include "DIO.h"
#include "ADC_REG.h"
#include <stdlib.h>
#include "LCD.h"
unsigned short ADC_Read(unsigned char Channel);
void ADC_Init();
#ifndef ADC_H_
#define ADC_H_
void ADC_Init();
#endif /* ADC_H_ */
﻿/*
 * ADC.c
 *
 * Created: 16/10/2020 12:01:48 ص
 *  Author: hp
 */ 
#include "ADC.h"
void ADC_Init(){
	ADMUX_REG|=(1<<6)|(1<<7);				//Use Internal 2.56V Voltage Reference with external capacitor at AREF Pin
	ADCSRA_REG|=(1<<7)|(1<<0)|(1<<1)|(1<<2);// Enabling ADC, USING PRESCaler 128;
	DIO_Init(DIO_ChannelA0,Input);
}
unsigned short ADC_Read(unsigned char Channel){
	unsigned short Data;
	ADMUX_REG=(ADMUX_REG & 0xE0)|(Channel & 0x1F );
	ADCSRA_REG|=(1<<6);	//Start conversion//
						//wait 25 or 13 ADC clock cycle
	while(!(ADCSRA_REG&(1<<4)));	// flag is set when the 25 clock cycle finished
	ADCSRA_REG|=(1<<4);					//clear ADIF Manually
	ADMUX_REG|=(1<<5);
	Data=(ADCL_REG>>6);
	Data|=(ADCH_REG<<2);
	return Data;
}
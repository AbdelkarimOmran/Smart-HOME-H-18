/*
 * SLAVE_MC.c
 *
 * Created: 20/10/2020 11:37:55 م
 * Author : hp
 */ 
#include "ADC.h"
#include "LCD.h"
#include "SPI.h"
#include "TIMER0.h"
Uint8 OCRF=0;
int main(void)
{
	DIO_Init(DIO_ChannelC1,Output);	
	DIO_Init(DIO_ChannelC2,Output);	
	DIO_Init(DIO_ChannelC3,Output);	
	DIO_Init(DIO_ChannelB3,Output);//OC0
	DIO_Write(DIO_ChannelB3,STD_Low);//OC0
   Uint8 count=0;
	short T=0;
	Uint8 MOTOR_FLAG=0;
	SPI_Init('S');
	LCD_Init();
	ADC_Init();
	TCCR0_REG |=(1<<WGM00)|(1<<CS00)|(1<<CS01)|(1<<COM01);
	char SS;
	char buffer[5];
    	while (1)
    	{
			OCR0_REG=OCRF;
	    	SS=SPI_Receive();
			switch(SS){
				case '1':
		    	DIO_Write(DIO_ChannelC1,STD_High);//led on
				
			break;
			case '2':
		    	DIO_Write(DIO_ChannelC1,STD_Low);;//led off
		   break;
			
		case '3':
			OCRF=0;
			DIO_Write(DIO_ChannelC2,STD_High);
			DIO_Write(DIO_ChannelC3,STD_Low);
			MOTOR_FLAG=1;
			LCD_CMD(0x01);
			LCD_String("SPEED 0");
			//Motor on Speed =0;
		break;
		case '4':
			OCRF=0;
			DIO_Write(DIO_ChannelC2,STD_Low);
			DIO_Write(DIO_ChannelC3,STD_Low);
			MOTOR_FLAG=0;
			count=0;
			//Motor off
		break;
	    	
		case '+' :
	    	{
		if (MOTOR_FLAG==0)
		{
			LCD_CMD(0x01);
			LCD_String("MOTOR IS OFF!!!!");
		}
		else
					{count++;
					switch(count)
					{
						case 1:
						OCRF =63;
						LCD_CMD(0x01);
						LCD_String("SPEED 25%");
						break;
						case 2:
						OCRF =127;
						LCD_CMD(0x01);
						LCD_String("SPEED 50%");
						break;
						case 3:
						OCRF =191;
						LCD_CMD(0x01);
						LCD_String("SPEED 75%");
						break;
						case 4:
						OCRF =255;
						LCD_CMD(0x01);
						LCD_String("SPEED 100%");
						break;
					
				}
				if (count>4)
				{
					count=4;
				}
					}
			}
				
			break;
			
	    	case '-' :
	    	{
				if (MOTOR_FLAG==0)
				{
					LCD_CMD(0x01);
					LCD_String("MOTOR IS OFF!!!!");
				}
				else
					{count--;
					switch(count)
					{
						case 0:
						OCRF =0;
						LCD_CMD(0x01);
						LCD_String(" SPEED = 0 ");
						break;
						case 1:
						OCRF =63;
						LCD_CMD(0x01);
						LCD_String("SPEED = 25% ");
						break;
						case 2:
						OCRF =127;
						LCD_CMD(0x01);
						LCD_String("SPEED = 50% ");
						break;
						case 3:
						OCRF =191;
						LCD_CMD(0x01);
						LCD_String("SPEED = 75% ");
						break;
						case 4:
						OCRF =255;
						LCD_CMD(0x01);
						LCD_String("SPEED = 100% ");
						break;
					}
					if (count<0)
					{
						count=0;
					}
					}
				
				break;
	    	}
	    case '5' :
	    	{
		    	for (Uint8 i=0;i<5;i++)
		    	{
					T=ADC_Read(0);
		    	}
				T /=4;
				itoa(T,buffer,10);
		    	LCD_POS(First_Line,0);
		    	LCD_String("The temperature =" );
		    	LCD_POS(Second_Line,0);
		    	LCD_String(buffer);	
	    	}
			break;
    	}
}
}



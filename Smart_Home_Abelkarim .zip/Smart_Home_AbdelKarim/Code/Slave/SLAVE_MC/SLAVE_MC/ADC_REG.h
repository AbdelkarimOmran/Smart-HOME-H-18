﻿/*
 * ADC_REG.h
 *
 * Created: 16/10/2020 12:03:17 ص
 *  Author: hp
 */ 


#ifndef ADC_REG_H_
#define ADC_REG_H_
#define ADMUX_REG (*((volatile Uint8*)0x27))
#define ADCSRA_REG (*((volatile Uint8*)0x26))
#define ADCH_REG (*((volatile Uint8*)0x25))
#define ADCL_REG (*((volatile Uint8*)0x24))
#endif /* ADC_REG_H_ */
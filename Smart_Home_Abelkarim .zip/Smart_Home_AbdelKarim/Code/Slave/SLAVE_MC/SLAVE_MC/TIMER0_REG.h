﻿/*
 * TIMER0_REG.h
 *
 * Created: 18/10/2020 12:19:02 ص
 *  Author: hp
 */ 


#ifndef TIMER0_REG_H_
#define TIMER0_REG_H_
#define TIMSK_REG   (*((volatile Uint8*)0x59))//Timer Interrupt Mask (Timer over flow&Timer Output Compare match -->(interrupt enable))
#define TIFR_REG    (*((volatile Uint8*)0x58))//Timer interrupt Flag (Timer flag over flow , Output compare Match Flag)
#define TCCR0_REG   (*((volatile Uint8*)0x53))//Timer/Counter Control Reg (WMG01,WGM00(3,6))(CS02,CS01,SC00)(COM01,COM00)
#define TCNT0_REG   (*((volatile Uint8*)0x52))//8-Bit Data Reg
#define OCR0_REG    (*((volatile Uint8*)0x5C))//Output Compare Register



#endif /* TIMER0_REG_H_ */